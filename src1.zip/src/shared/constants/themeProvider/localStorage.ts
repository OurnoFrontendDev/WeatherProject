export const THEME_LOCAL_STORAGE_KEY = "theme";
export const MANUAL_OVERRIDE_LOCAL_STORAGE_KEY = "manualOverride";
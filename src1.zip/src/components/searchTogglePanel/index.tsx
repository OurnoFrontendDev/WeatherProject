import React from "react";
import { TempUnitSwitcher } from "../tempUnitSwitcher";
import { SearchCityWeather } from "../searchCityWeather";
import { ToggleSwitchTheme } from "../toggleTheme";
import {
  SwitchTemperatureMetricContainer,
  SearchCityWeatherContainer, ThemeTemperatureToggleContainer,
} from "./searchTogglePanel.styled";

export const SearchToggleTemperatureUnitPanel = () => {
  return (
    <SwitchTemperatureMetricContainer>
      <SearchCityWeatherContainer>
        <SearchCityWeather />
      </SearchCityWeatherContainer>
      <ThemeTemperatureToggleContainer>
        <ToggleSwitchTheme />
        <TempUnitSwitcher />
      </ThemeTemperatureToggleContainer>
    </SwitchTemperatureMetricContainer>
  );
};

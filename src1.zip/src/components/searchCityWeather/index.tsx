import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { fetchWeatherBySearch } from "../features/weatherSlice";
import axios from "axios";
import { useTypedSelector } from "../../hooks/useTypedSelector";
import {
  SearchWeatherInput,
  SearchCitiesList,
  SearchCitiesListTownItem,
} from "./searchCityWeather.styled";
import { useDebounce } from "../../hooks/useDebounce";

interface City {
  name: string;
  country: string;
  latitude: number;
  longitude: number;
}

export const SearchCityWeather = () => {
  const dispatch = useDispatch();
  const weather = useTypedSelector((state) => state.weather);

  const [city, setCity] = useState("");
  const [suggestions, setSuggestions] = useState<City[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const debouncedSearchWeatherCity = useDebounce(city, 500);

  useEffect(() => {
    dispatch(
      fetchWeatherBySearch({
        name: city,
      }),
    );
  }, [dispatch]);

  const fetchCitiesFromNewApi = async (query: string) => {
    if (query.trim()) {
      try {
        const response = await axios.get(
          "https://geocoding-api.open-meteo.com/v1/search",
          {
            params: {
              name: query,
              count: 10,
              language: "en",
              format: "json",
            },
          },
        );

        if (response.data.results) {
          setSuggestions(response.data.results);
          setShowSuggestions(true);
        } else {
          setSuggestions([]);
          setShowSuggestions(false);
        }
      } catch (error) {
        console.error("Error fetching city suggestions:", error);
        setSuggestions([]);
        setShowSuggestions(false);
      }
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  useEffect(() => {
    if (debouncedSearchWeatherCity) {
      fetchCitiesFromNewApi(debouncedSearchWeatherCity);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [debouncedSearchWeatherCity]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCity(e.target.value);
  };

  const handleSelectCity = (selectedCity: City) => {
    if (selectedCity) {
      setCity(selectedCity.name);
      setShowSuggestions(false);
      dispatch(
        fetchWeatherBySearch({
          location: {
            latitude: selectedCity.latitude,
            longitude: selectedCity.longitude,
          },
          weatherUnit: weather.unit,
          name: selectedCity.name,
        }),
      );
    } else {
      console.error("Selected city is null or undefined");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && city.trim()) {
      dispatch(
        fetchWeatherBySearch({
          name: city,
          weatherUnit: weather.unit,
        }),
      );
      setShowSuggestions(false);
    }
  };

  return (
    <>
      <SearchWeatherInput
        type="text"
        value={city}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        placeholder="Enter city name"
      />
      {showSuggestions && suggestions.length > 0 && (
        <SearchCitiesList>
          {suggestions.map((suggestion: City, index: number) => (
            <SearchCitiesListTownItem
              key={index}
              onClick={() => handleSelectCity(suggestion)}
            >
              {suggestion.name}, {suggestion.country}
            </SearchCitiesListTownItem>
          ))}
        </SearchCitiesList>
      )}
    </>
  );
};
//
//
// import React, { useState, useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import {
//   fetchSuggestionsStart,
//   clearSuggestions,
//   fetchWeatherBySearch,
// } from "../features/weatherSlice";
// import { RootState } from "../../state/store";
// import {
//   SearchWeatherInput,
//   SearchCitiesList,
//   SearchCitiesListTownItem,
// } from "./searchCityWeather.styled";
// import { useDebounce } from "../../hooks/useDebounce";
//
// export const SearchCityWeather = () => {
//   const dispatch = useDispatch();
//   const { suggestions, loadingSuggestions } = useSelector((state: RootState) => state.weather);
//
//   const [city, setCity] = useState("");
//   const debouncedCity = useDebounce(city, 500);
//
//   useEffect(() => {
//     if (debouncedCity) {
//       dispatch(fetchSuggestionsStart(debouncedCity));
//     } else {
//       dispatch(clearSuggestions());
//     }
//   }, [debouncedCity, dispatch]);
//
//   const handleSelectCity = (selectedCity: { name: string; latitude: number; longitude: number }) => {
//     setCity(selectedCity.name);
//     dispatch(
//       fetchWeatherBySearch({
//         name: selectedCity.name,
//         weatherUnit: "celsius",
//       }),
//     );
//   };
//
//   return (
//     <>
//       <SearchWeatherInput
//         type="text"
//         value={city}
//         onChange={(e) => setCity(e.target.value)}
//         placeholder="Enter city name"
//       />
//       {loadingSuggestions && <div>Loading...</div>}
//       {!loadingSuggestions && suggestions.length > 0 && (
//         <SearchCitiesList>
//           {suggestions.map((suggestion, index) => (
//             <SearchCitiesListTownItem
//               key={index}
//               onClick={() => handleSelectCity(suggestion)}
//             >
//               {suggestion.name}, {suggestion.country}
//             </SearchCitiesListTownItem>
//           ))}
//         </SearchCitiesList>
//       )}
//     </>
//   );
// };
